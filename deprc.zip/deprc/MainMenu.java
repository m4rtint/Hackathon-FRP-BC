package ca.frpbc;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

public class MainMenu extends Activity{

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// Auto generated on create.
		super.onCreate(savedInstanceState);
		//setContentView(R.layout.activity_mainmenu);
		
		// Initialize search.
		Search.getDummySearchInstance(this);
	}
	public void goToSearch(View view){
		Intent intent = new Intent("ca.frpbc.SearchActivity");
		startActivity(intent);
	}

	public void goToCu(View view){
		Intent intent = new Intent("ca.frpbc.ContactUs");
		startActivity(intent);
	}

	public void goToTw(View view){
		goToUrl("http://twitter.com/frpbc");
	}

	public void goToFb(View view){
		goToUrl("http://facebook.com/frpbc");
	}
	
	private void goToUrl(String url) {
		Uri uriUrl = Uri.parse(url);
		Intent launchBrowser = new Intent(Intent.ACTION_VIEW, uriUrl);
		startActivity(launchBrowser);
	}
}
