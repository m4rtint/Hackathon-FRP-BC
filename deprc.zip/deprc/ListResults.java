package ca.frpbc;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.view.View;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.app.ListFragment;
import android.content.Intent;

public class ListResults extends ListFragment implements SearchActivity.ResultDisplay {
	
	@Override
	public void onListItemClick (ListView l, View v, int position, long id) {
		super.onListItemClick(l, v, position, id);
		Object rawData = getListView().getItemAtPosition(position);
		if (rawData instanceof Map<?, ?>) {
			Map<?, ?> map = (Map<?, ?>)rawData;
			Object rawPoi = map.get("poi");
			if (rawPoi instanceof PointOfInterest) {
				Intent intent = new Intent("ca.frpbc.POIDetails");
				intent.putExtra(POIDetails.PARCEL_EXTRA_NAME, (PointOfInterest)rawPoi);
				startActivity(intent);
			}
		}
	}
	
	@Override
	public void showResults(SearchActivity context, List<PointOfInterest> results) {
		List<? extends Map<String, ?>> dataMap = createDataMap(results);
		int resource = android.R.layout.simple_list_item_1;
		String[] from = new String[] { "text1" };
		int[] to = new int[] { android.R.id.text1 };
		ListAdapter adapter = new SimpleAdapter(context, dataMap, resource, from, to);
		
		setListAdapter(adapter);
	}
	
	private List<Map<String, ?>> createDataMap(List<PointOfInterest> results) {
		List<Map<String, ?>> out = new ArrayList<Map<String, ?>>();
		for (PointOfInterest poi : results) {
			Map<String, Object> row = new HashMap<String, Object>();
			row.put("text1", poi.getName());
			row.put("poi", poi);
			out.add(row);
		}
		return out;
	}
}
